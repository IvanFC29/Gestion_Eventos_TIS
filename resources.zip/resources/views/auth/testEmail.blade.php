<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <title>correo Electronico</title>
</head>
<body>
    <h1>Estimado Usuario ha solicitado recuperar su contraseña</h1>
    <p>Su contraseña es la siguiente :  {{$details}} </p>
  
    <br>
    <p>Gracias por su atencion, que tenga un buen dia!!

    </p>
</body>
</html>