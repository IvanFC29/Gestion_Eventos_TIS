<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UsuarioeventosController extends Controller
{
    //
    public function uEventos()
    {
        //return view('eventosusuario');
        echo "Hola";
    }
}
