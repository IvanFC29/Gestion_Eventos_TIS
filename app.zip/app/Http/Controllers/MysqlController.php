<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MysqlController extends Controller
{
    public function obtenerTE(){
        return "Todos los eventos";
    }
}
